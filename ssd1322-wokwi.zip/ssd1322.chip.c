// Wokwi Custom Chip - For docs and examples see:
// https://docs.wokwi.com/chips-api/getting-started
//
// SPDX-License-Identifier: MIT
// Copyright 2023 Muhammad Syazwan (Wan)
// Modified heavily by Jonah Grasso 

#include "wokwi-api.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define CMD_ENABLE_GRAYSCALE_TABLE 0x00
#define CMD_SET_COLUMN_ADDRESS 0x15
#define CMD_SET_ROW_ADDRESS 0x75
#define CMD_SET_DISPLAY_OFF 0xAE
#define CMD_SET_DISPLAY_ON 0xAF
// ... (add other commands as needed) ...


typedef struct {
  pin_t Vss;
  pin_t Vdd;
  pin_t NC0;
  pin_t DC;
  pin_t RW;
  pin_t E;
  pin_t DB0;
  pin_t DB1;
  pin_t DB2;
  pin_t DB3;
  pin_t DB4;
  pin_t DB5;
  pin_t DB6;
  pin_t DB7;
  pin_t NC1;
  pin_t RES;
  pin_t CS;
  pin_t NC2;
  pin_t BS1;
  pin_t BS0;
  uint64_t time;
} chip_data_t; 

bool parallel_6800 = false;
bool parallel_8080 = false;
bool three_wire = false;
bool four_wire = false;

void chip_timer_callback(void *data) {
  chip_data_t *chip_data = (chip_data_t*)data;
  float Vdd = pin_adc_read(chip_data->Vdd);
  bool VddInRange = Vdd >= 2.8 && Vdd <= 3.5;
  bool db0low = pin_read(chip_data->DB0); // 0, and 1 will be used for 3/4 wire operation 
  bool db1low = pin_read(chip_data->DB1);
  bool db2low = pin_read(chip_data->DB2); // NC with 3/4-wire operation
  bool db3low = pin_read(chip_data->DB3);
  bool db4low = pin_read(chip_data->DB4);
  bool db5low = pin_read(chip_data->DB5);
  bool db6low = pin_read(chip_data->DB6);
  bool db7low = pin_read(chip_data->DB7);
  // If bs0 and BS1 are high, use 6800 parallel 8-bit
  // If only bs1 is high, use 8080 Parallel 8-bit
  // If only BS0 high, 3-wire spi 
  // If both are low, 4-wire spi
  bool bs0High = pin_read(chip_data->BS0);  // 1: bs0 high ->6800 8-bit 2: bs0 low ->8080 8-bit 3: bs0 high ->3-wire 4: bs0 low ->4-wire
  bool bs0Low = pin_read(chip_data->BS0);
  bool bs1High = pin_read(chip_data->BS1);  // 1: bs1 high ->6800 8-bit 2: bs1 high ->8080 8-bit 3: bs1 low ->3-wire 4: bs1 low ->4-wire
  bool bs1Low = pin_read(chip_data->BS0);

  bool clearTime = false;
  uint64_t now = get_sim_nanos();
  uint64_t time = chip_data->time;
  if (now - time > 5000000000) {  // Make sure this works right
    clearTime = true;
    chip_data->time = now;
  }

  if (!clearTime && VddInRange && bs0High && bs1High) {
      // 6800 Parallel
      parallel_6800 = true;
      parallel_8080 = false;
      three_wire = false;
      four_wire = false;
  }
  else if (!clearTime && VddInRange && bs0Low && bs1High) {
      // 8080 Parallel
      parallel_6800 = false;
      parallel_8080 = true;
      three_wire = false;
      four_wire = false;
  }
  else if (!clearTime && VddInRange && bs0High && bs1Low) {
      // 3-wire SPI
      parallel_6800 = false;
      parallel_8080 = false;
      three_wire = true;
      four_wire = false;
  }
  else if (!clearTime && VddInRange && bs0Low && bs1Low) {
      // 4-wire SPI
      parallel_6800 = false;
      parallel_8080 = false;
      three_wire = false;
      four_wire = true;
  }
  else {
    printf("Failed to detect communication type./n");
    free(chip_data);
    return;
  }
}


const uint8_t multi_byte_commands[] = {
    [CMD_SET_COLUMN_ADDRESS] = 2,
    [CMD_SET_ROW_ADDRESS] = 2,
    // ... other multi-byte commands ...
};

#define F_OSC 1940000

enum ssd1322_addr_increment {
    HORIZONTAL_ADDR_INCREMENT = 0,
    VERTICAL_ADDR_INCREMENT = 1
};

typedef struct {
    uint32_t width;
    uint32_t height;
    uint8_t pixels[256 * 64 / 2];
    buffer_t framebuffer;
    timer_t update_timer;

    bool display_on;
    bool updated;
    uint8_t contrast;
    bool invert;
    bool reverse_rows;
    bool segment_remap;
    bool use_grayscale_table;
    uint8_t grayscale_table[15];
    enum ssd1322_addr_increment addr_increment;
    bool partial_mode;

    uint8_t clock_divider;
    uint8_t multiplex_ratio;
    uint8_t phase1;
    uint8_t phase2;

    uint16_t active_column;
    uint16_t column_start;
    uint16_t column_end;
    uint8_t active_row;
    uint8_t row_start;
    uint8_t row_end;
    uint8_t partial_row_start;
    uint8_t partial_row_end;

    uint8_t start_line;
    uint8_t display_offset;

    bool control_byte;
    bool continuous_mode;
    bool command_mode;
    uint8_t current_command_index;
    uint8_t current_command_length;
    uint8_t current_command[16];
} ssd1322_state_t;

static void ssd1322_reset(ssd1322_state_t *state) {
    state->width = 256;
    state->height = 64;
    state->contrast = 0x7F;
    state->clock_divider = 1;
    state->current_command_index = 0;
    state->active_column = 0;
    state->column_start = 0;
    state->column_end = 255;
    state->active_row = 0;
    state->row_start = 0;
    state->row_end = 63;
    state->start_line = 0;
    state->display_offset = 0;
    state->invert = false;
    state->updated = false;
    state->addr_increment = HORIZONTAL_ADDR_INCREMENT;
}

static uint32_t frame_frequency(ssd1322_state_t *state) {
    uint8_t X = 10 + /*GS15*/ 112;
    uint8_t K = state->phase1 + state->phase2 + X;
    return F_OSC / (state->clock_divider * K * (1 + state->multiplex_ratio));
}

void ssd1322_update_buffer(void *user_data) {
    ssd1322_state_t *state = user_data;
    const uint8_t *pixels = state->pixels;
    const bool invert = state->invert;
    const bool display_on = state->display_on;
    const bool reverse_rows = state->reverse_rows;
    const uint8_t start_line = state->start_line;
    const uint8_t width = state->width;
    const uint8_t height = state->height;

    for (uint8_t y = 0; y < height; y++) {
        for (uint8_t x = 0; x < width; x++) {
            const uint16_t scr_y = y + start_line;
            const uint16_t virtual_y = (reverse_rows ? height - 1 - scr_y : scr_y) % height;
            const uint16_t pix_index = virtual_y * width + (x / 2);
            const uint8_t pix_value = x % 2 == 0 ? pixels[pix_index] & 0xF : pixels[pix_index] >> 4;
            const uint8_t pix_with_inv = invert ? 0xF - pix_value : pix_value;
            const uint32_t data_offset = (y * width + x) * 4;
            uint32_t pixel = display_on ? 0xFF << 24 | pix_with_inv << 16 | pix_with_inv << 8 | pix_with_inv : 0;

            buffer_write(state->framebuffer, data_offset, &pixel, sizeof(pixel));
        }
    }
    state->updated = false;
}

void ssd1322_schedule_update(ssd1322_state_t *state) {
    if (!state->updated) {
        state->updated = true;
        timer_start(state->update_timer, 16667, false);
    }
}

static void ssd1322_process_command(ssd1322_state_t *state) {
    uint8_t command_code = state->current_command[0];
    bool auto_update = false;
    switch (command_code) {
        case CMD_ENABLE_GRAYSCALE_TABLE:
            state->use_grayscale_table = true;
            break;
        case CMD_SET_COLUMN_ADDRESS:
            state->column_start = state->current_command[1] & 0x7F;
            state->column_end = state->current_command[2] & 0x7F;
            break;
        case CMD_SET_ROW_ADDRESS:
            state->row_start = state->current_command[1] & 0x7F;
            state->row_end = state->current_command[2] & 0x7F;
            break;
        case CMD_SET_DISPLAY_OFF:
            state->display_on = false;
            break;
        case CMD_SET_DISPLAY_ON:
            state->display_on = true;
            break;
        // Add more cases as needed for additional commands
        default:
            break;
    }
    if (auto_update && state->display_on) {
        ssd1322_schedule_update(state);
    }
    state->current_command_index = 0;
}

void ssd1322_spi_done(void *user_data, uint8_t *data, uint32_t len) {
    ssd1322_state_t *state = user_data;
    if (state->command_mode) {
        for (uint32_t i = 0; i < len; i++) {
            state->current_command[state->current_command_index++] = data[i];
            if (state->current_command_index == state->current_command_length) {
                ssd1322_process_command(state);
                break;
            }
        }
    } else {
        for (uint32_t i = 0; i < len; i++) {
            uint16_t idx = state->active_row * state->width / 2 + state->active_column / 2;
            state->pixels[idx] = data[i];
            state->active_column++;
            if (state->active_column > state->column_end) {
                state->active_column = state->column_start;
                state->active_row++;
                if (state->active_row > state->row_end) {
                    state->active_row = state->row_start;
                }
            }
        }
        ssd1322_schedule_update(state);
    }
}

void chip_init() {
    ssd1322_state_t *chip = malloc(sizeof(ssd1322_state_t));
    if (!chip) {
        fprintf(stderr, "Failed to allocate memory for SSD1322 state\n");
        return;
    }

    ssd1322_reset(chip);

    // SPI configuration (ensure the pins are initialized here)
    const spi_config_t spi = {
        chip_data->Vss = pin_init("VSS", INPUT)
        .DC = pin_init("DC", INPUT)
        .DB0 = pin_init("DB0", INPUT)
        .DB1 = pin_init("DB1", INPUT)
        .RES = pin_init("RES", INPUT)
        .CS = pin_init("CS", INPUT)
        .done = ssd1322_spi_done,
        .user_data = chip,
    };
    
    spi_init(&spi);

    // Framebuffer initialization
    chip->framebuffer = framebuffer_init(&chip->width, &chip->height);
    printf("Framebuffer dimensions: %ux%u\n", chip->width, chip->height); // Debugging output
    if (!chip->framebuffer) {
        fprintf(stderr, "Failed to initialize framebuffer: %ux%u\n", chip->width, chip->height);
        free(chip);
        return;
    }

    // Timer configuration
    const timer_config_t timer_config = {
        .callback = ssd1322_update_buffer,
        .user_data = chip,
    };
    chip->update_timer = timer_init(&timer_config);

    printf("SSD1322 Custom Chip Initialized!\n");
}