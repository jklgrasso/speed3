/*
https:www.ti.com/lit/ds/symlink/txs0108e.pdf

This device is an 8-bit non-inverting level translator
that uses two separate configurable power-supply
rails. The A port tracks the VCCA pin supply voltage.
The VCCA pin accepts any supply voltage between 1.4
V and 3.6 V. The B port tracks the VCCB pin supply
voltage. The VCCB pin accepts any supply voltage
between 1.65 V and 5.5 V. Two input supply pins
allows for low Voltage bidirectional translation
between any of the 1.5 V, 1.8 V, 2.5 V, 3.3 V, and 5
V voltage nodes.
When the output-enable (OE) input is low, all outputs
are placed in the high-impedance (Hi-Z) state.
*/

#include "wokwi-api.h"
#include <stdio.h>
#include <stdlib.h>

typedef struct {
  pin_t Vcca;
  pin_t Vccb;
  pin_t OE;
  pin_t GND;
  pin_t A1;
  pin_t A2;
  pin_t A3;
  pin_t A4;
  pin_t A5;
  pin_t A6;
  pin_t A7;
  pin_t A8;
  pin_t B1;
  pin_t B2;
  pin_t B3;
  pin_t B4;
  pin_t B5;
  pin_t B6;
  pin_t B7;
  pin_t B8;
  uint64_t time;
} chip_data_t;

void chip_timer_callback(void *data) 
{
  chip_data_t *chip_data = (chip_data_t*)data;
  float Vcca = pin_adc_read(chip_data->Vcca);
  float Vccb = pin_adc_read(chip_data->Vccb);
  bool oeHigh = pin_read(chip_data->OE);
  bool VccaInRange = Vcca >= 1.4 && Vcca <= 3.6;
  bool VccbInRange = Vcca >= 1.65 && Vcca <= 5.5;

  bool clearTime = false;
  uint64_t now = get_sim_nanos();
  uint64_t time = chip_data->time;
  if (now - time > 5000000000)
  {
    clearTime = true;
    chip_data->time = now;
  }

  if (!clearTime && oeHigh && VccaInRange && VccbInRange && Vcca <= Vccb)
  {
    if (pin_adc_read(chip_data->A1) == Vcca)
    {
      pin_dac_write(chip_data->B1, Vccb);
    }
    else if (pin_adc_read(chip_data->B1) == Vccb)
    {
      pin_dac_write(chip_data->A1, Vcca);
    }

    if (pin_adc_read(chip_data->A2) == Vcca)
    {
      pin_dac_write(chip_data->B2, Vccb);
    }
    else if (pin_adc_read(chip_data->B2) == Vccb)
    {
      pin_dac_write(chip_data->A2, Vcca);
    }

    if (pin_adc_read(chip_data->A3) == Vcca)
    {
      pin_dac_write(chip_data->B3, Vccb);
    }
    else if (pin_adc_read(chip_data->B3) == Vccb)
    {
      pin_dac_write(chip_data->A3, Vcca);
    }

    if (pin_adc_read(chip_data->A4) == Vcca)
    {
      pin_dac_write(chip_data->B4, Vccb);
    }
    else if (pin_adc_read(chip_data->B4) == Vccb)
    {
      pin_dac_write(chip_data->A4, Vcca);
    }

    if (pin_adc_read(chip_data->A5) == Vcca)
    {
      pin_dac_write(chip_data->B5, Vccb);
    }
    else if (pin_adc_read(chip_data->B5) == Vccb)
    {
      pin_dac_write(chip_data->A5, Vcca);
    }

    if (pin_adc_read(chip_data->A6) == Vcca)
    {
      pin_dac_write(chip_data->B6, Vccb);
    }
    else if (pin_adc_read(chip_data->B6) == Vccb)
    {
      pin_dac_write(chip_data->A6, Vcca);
    }

    if (pin_adc_read(chip_data->A7) == Vcca)
    {
      pin_dac_write(chip_data->B7, Vccb);
    }
    else if (pin_adc_read(chip_data->B7) == Vccb)
    {
      pin_dac_write(chip_data->A7, Vcca);
    }

    if (pin_adc_read(chip_data->A8) == Vcca)
    {
      pin_dac_write(chip_data->B8, Vccb);
    }
    else if (pin_adc_read(chip_data->B8) == Vccb)
    {
      pin_dac_write(chip_data->A8, Vcca);
    }
  }
  else
  {
      pin_dac_write(chip_data->A1, 0);
      pin_dac_write(chip_data->A2, 0);
      pin_dac_write(chip_data->A3, 0);
      pin_dac_write(chip_data->A4, 0);
      pin_dac_write(chip_data->A5, 0);
      pin_dac_write(chip_data->A6, 0);
      pin_dac_write(chip_data->A7, 0);
      pin_dac_write(chip_data->A8, 0);

      pin_dac_write(chip_data->B1, 0);
      pin_dac_write(chip_data->B2, 0);
      pin_dac_write(chip_data->B3, 0);
      pin_dac_write(chip_data->B4, 0);
      pin_dac_write(chip_data->B5, 0);
      pin_dac_write(chip_data->B6, 0);
      pin_dac_write(chip_data->B7, 0);
      pin_dac_write(chip_data->B8, 0);

      pin_dac_write(chip_data->Vcca, Vcca);
      pin_dac_write(chip_data->Vccb, Vccb);
  }
}

void chip_init() 
{
  chip_data_t *chip_data = (chip_data_t*)malloc(sizeof(chip_data_t));
  chip_data->Vcca = pin_init("Vcca", ANALOG);
  chip_data->Vccb = pin_init("Vccb", ANALOG);
  chip_data->A1 = pin_init("A1", ANALOG);
  chip_data->A2 = pin_init("A2", ANALOG);
  chip_data->A3 = pin_init("A3", ANALOG);
  chip_data->A4 = pin_init("A4", ANALOG);
  chip_data->A5 = pin_init("A5", ANALOG);
  chip_data->A6 = pin_init("A6", ANALOG);
  chip_data->A7 = pin_init("A7", ANALOG);
  chip_data->A8 = pin_init("A8", ANALOG);
  chip_data->B1 = pin_init("B1", ANALOG);
  chip_data->B2 = pin_init("B2", ANALOG);
  chip_data->B3 = pin_init("B3", ANALOG);
  chip_data->B4 = pin_init("B4", ANALOG);
  chip_data->B5 = pin_init("B5", ANALOG);
  chip_data->B6 = pin_init("B6", ANALOG);
  chip_data->B7 = pin_init("B7", ANALOG);
  chip_data->B8 = pin_init("B8", ANALOG);
  chip_data->OE = pin_init("OE", INPUT);

  const timer_config_t config = 
  {
    .callback = chip_timer_callback,
    .user_data = chip_data,
  };

  timer_t timer_id = timer_init(&config);
  timer_start(timer_id, 10000, true);
}
